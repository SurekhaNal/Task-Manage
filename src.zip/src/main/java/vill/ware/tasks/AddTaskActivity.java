package vill.ware.tasks;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class AddTaskActivity extends AppCompatActivity {


    EditText taskText;
    Button taskSubmitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_task);


        taskSubmitButton = findViewById(R.id.taskSubmitButton);
        taskText = (EditText) findViewById(R.id.taskText);

        taskSubmitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                SharedPreferences sharedPref = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);
                String task4 = sharedPref.getString("task4", "No task found");
                String task3 = sharedPref.getString("task3", "No task found");
                String task2 = sharedPref.getString("task2", "No task found");
                String task1 = sharedPref.getString("task1", "No task found");

                String task = taskText.getText().toString();

                SharedPreferences.Editor editor = sharedPref.edit();
                editor.putString("task5", task4);
                editor.putString("task4", task3);
                editor.putString("task3", task2);
                editor.putString("task2", task1);
                editor.putString("task1", task);
                editor.apply();

                Intent intent = new Intent(AddTaskActivity.this, TaskListActivity.class);
                startActivity(intent);
            }
        });

    }
}