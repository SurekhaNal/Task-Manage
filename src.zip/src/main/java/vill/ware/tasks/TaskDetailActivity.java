package vill.ware.tasks;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class TaskDetailActivity extends AppCompatActivity {


    TextView taskDetail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_task_detail);



        taskDetail = findViewById(R.id.taskDetail);

        Intent intent = getIntent();
        String taskD = intent.getStringExtra("taskDetail");

        taskDetail.setText(taskD);

    }

    @Override
    public void onBackPressed() {
        finish();
    }
}