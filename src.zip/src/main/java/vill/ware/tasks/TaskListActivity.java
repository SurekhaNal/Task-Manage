package vill.ware.tasks;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class TaskListActivity extends AppCompatActivity {

    Button addTaskButton;
    TextView task1TV,task2TV,task3TV,task4TV,task5TV;
    String task1="",task2="",task3="",task4="",task5="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_task_list);


        addTaskButton = findViewById(R.id.addTaskButton);
        task1TV = findViewById(R.id.task1);
        task2TV = findViewById(R.id.task2);
        task3TV = findViewById(R.id.task3);
        task4TV = findViewById(R.id.task4);
        task5TV = findViewById(R.id.task5);

        setTaskData();

        task1TV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(TaskListActivity.this, TaskDetailActivity.class);
                intent.putExtra("taskDetail",task1);
                startActivity(intent);
            }
        });

        task2TV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(TaskListActivity.this, TaskDetailActivity.class);
                intent.putExtra("taskDetail",task2);
                startActivity(intent);
            }
        });

        task3TV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(TaskListActivity.this, TaskDetailActivity.class);
                intent.putExtra("taskDetail",task3);
                startActivity(intent);
            }
        });

        task4TV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(TaskListActivity.this, TaskDetailActivity.class);
                intent.putExtra("taskDetail",task4);
                startActivity(intent);
            }
        });

        task5TV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(TaskListActivity.this, TaskDetailActivity.class);
                intent.putExtra("taskDetail",task5);
                startActivity(intent);
            }
        });

        addTaskButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(TaskListActivity.this, AddTaskActivity.class);
                startActivity(intent);
            }
        });

    }

    public void setTaskData(){

        SharedPreferences sharedPref = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE);

        task5 = sharedPref.getString("task5", "No Task5 found");
        task4 = sharedPref.getString("task4", "No Task4 found");
        task3 = sharedPref.getString("task3", "No Task3 found");
        task2 = sharedPref.getString("task2", "No Task2 found");
        task1 = sharedPref.getString("task1", "No Task1 found");

        task1TV.setText("Task 1 - "+task1);
        task2TV.setText("Task 2 - "+task2);
        task3TV.setText("Task 3 - "+task3);
        task4TV.setText("Task 4 - "+task4);
        task5TV.setText("Task 5 - "+task5);



    }



    @Override
    public void onBackPressed() {
        finishAffinity();
    }


}