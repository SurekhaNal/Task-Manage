package vill.ware.tasks;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);


        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Intent to move from SplashActivity to MainActivity
                Intent intent = new Intent(MainActivity.this, TaskListActivity.class);
                startActivity(intent);

                // Close SplashActivity so user can't go back to it
                finish();
            }
        }, 4000);


    }
}